import PT1 from "../assets/images/PT1.webp";
import PT2 from "../assets/images/PT2.webp";
import PT3 from "../assets/images/PT3.webp";
import PT4 from "../assets/images/PT4.webp";

export default [
  {
    title: "Shop Multivitamin",
    image: PT1,
  },
  {
    title: "Shop Protein",
    image: PT2,
  },
  {
    title: "Shop Pregnanacy",
    image: PT3,
  },
  {
    title: "Shop Buldles",
    image: PT4,
  },
];
