import LandingPage from "./pages/landingPage/LandingPage";

const App = () => <LandingPage />;

export default App;